package com.ds;

import org.apache.flink.api.common.RuntimeExecutionMode;
import org.apache.flink.api.common.functions.FlatMapFunction;
import org.apache.flink.api.common.typeinfo.Types;
import org.apache.flink.api.java.functions.KeySelector;
import org.apache.flink.api.java.tuple.Tuple2;
import org.apache.flink.configuration.Configuration;
import org.apache.flink.configuration.RestOptions;
import org.apache.flink.streaming.api.datastream.DataStreamSource;
import org.apache.flink.streaming.api.datastream.SingleOutputStreamOperator;
import org.apache.flink.streaming.api.environment.StreamExecutionEnvironment;
import org.apache.flink.util.Collector;

public class SocketDsWithWebUI {
    public static void main(String[] args) throws Exception {
        //1、获取环境SparkContext、SparkSession
//        StreamExecutionEnvironment env = StreamExecutionEnvironment.getExecutionEnvironment();
        Configuration conf = new Configuration();
        conf.setString(RestOptions.BIND_PORT, "5201");
        StreamExecutionEnvironment env = StreamExecutionEnvironment.createLocalEnvironmentWithWebUI(conf);
        env.setParallelism(1);
//        env.disableOperatorChaining();
        //2、加载数据源（Source）
        DataStreamSource<String> source = env.socketTextStream("ds-bigdata-005", 9876);
        //3、转换（Transformation）
        source.map(value -> value)
                .flatMap((String value, Collector<Tuple2<String, Long>> out) -> {
                    String[] s = value.split(" ");
                    for (String str : s) {
                        // Hello World
                        // （Hello，1）
                        // （World，1）
                        out.collect(Tuple2.of(str, 1L));
                    }
                })
                .setParallelism(1)
                .startNewChain()
                .returns(Types.TUPLE(Types.STRING, Types.LONG))
                .keyBy(value -> value.f0)
                .sum(1)
                .print();

//        //4、输出（Sink）
//        sum.print();
        //5、手动开启执行execute
        env.execute();
    }
}


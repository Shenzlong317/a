package com.ds;

import org.apache.flink.api.common.functions.FlatMapFunction;
import org.apache.flink.api.java.functions.KeySelector;
import org.apache.flink.api.java.tuple.Tuple2;
import org.apache.flink.streaming.api.datastream.DataStreamSource;
import org.apache.flink.streaming.api.datastream.SingleOutputStreamOperator;
import org.apache.flink.streaming.api.environment.StreamExecutionEnvironment;
import org.apache.flink.streaming.api.functions.source.SourceFunction;
import org.apache.flink.util.Collector;

public class FlinkFirst {
    public static void main(String[] args) throws Exception {
        //1、获取环境SparkContext、SparkSession
        StreamExecutionEnvironment env = StreamExecutionEnvironment.getExecutionEnvironment();
        env.setParallelism(1);
        //2、加载数据源（Source）
        DataStreamSource<String> source = env.readTextFile("src/main/resources/abc.txt");
        //3、转换（Transformation）
        SingleOutputStreamOperator<Tuple2<String, Long>> sum = source.flatMap(new FlatMapFunction<String, Tuple2<String, Long>>() {
                    @Override
                    public void flatMap(String value, Collector<Tuple2<String, Long>> out) throws Exception {
                        String[] s = value.split(" ");
                        for (String str : s) {
                            // Hello World
                            // （Hello，1）
                            // （World，1）
                            out.collect(Tuple2.of(str, 1L));
                        }
                    }
                })
                .keyBy(new KeySelector<Tuple2<String, Long>, Object>() {
                    @Override
                    public Object getKey(Tuple2<String, Long> value) throws Exception {
                        return value.f0;
                    }
                })
                .sum(1);
        //4、输出（Sink）
        sum.print();

        // 空跑任务
        env.addSource(new EmptyJob()).print().setParallelism(1);
        //5、手动开启执行execute
        env.execute();

    }
}

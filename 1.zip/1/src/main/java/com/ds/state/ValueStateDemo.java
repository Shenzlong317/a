package com.ds.state;

import org.apache.commons.lang3.time.FastDateFormat;
import org.apache.flink.api.common.eventtime.SerializableTimestampAssigner;
import org.apache.flink.api.common.eventtime.WatermarkStrategy;
import org.apache.flink.api.common.functions.MapFunction;
import org.apache.flink.api.common.state.ValueState;
import org.apache.flink.api.common.state.ValueStateDescriptor;
import org.apache.flink.api.java.tuple.Tuple2;
import org.apache.flink.configuration.Configuration;
import org.apache.flink.streaming.api.datastream.DataStreamSource;
import org.apache.flink.streaming.api.environment.StreamExecutionEnvironment;
import org.apache.flink.streaming.api.functions.KeyedProcessFunction;
import org.apache.flink.streaming.api.functions.source.SourceFunction;
import org.apache.flink.util.Collector;

import java.time.Duration;
import java.util.Random;

public class ValueStateDemo {
    public static void main(String[] args) throws Exception {
        // 单词n秒不出现则输出
        StreamExecutionEnvironment env = StreamExecutionEnvironment.getExecutionEnvironment();

        // 造数
        DataStreamSource<Tuple2<String, Long>> source = env.addSource(new SourceFunction<Tuple2<String, Long>>() {
            boolean flag = true;

            @Override
            public void run(SourceContext<Tuple2<String, Long>> ctx) throws Exception {
                String[] str = {"张三", "李四", "王五", "赵六", "刘七"};
                while (flag) {
                    int i = new Random().nextInt(4);
                    Thread.sleep(1000L);
                    ctx.collect(new Tuple2<>(str[i], System.currentTimeMillis()));
                }
            }

            @Override
            public void cancel() {
                flag = false;
            }
        });

        // 水印策略
        WatermarkStrategy<Tuple2<String, Long>> ws = WatermarkStrategy.<Tuple2<String, Long>>forBoundedOutOfOrderness(Duration.ofSeconds(2))
                .withTimestampAssigner(new SerializableTimestampAssigner<Tuple2<String, Long>>() {
                    @Override
                    public long extractTimestamp(Tuple2<String, Long> stringLongTuple2, long l) {
                        return stringLongTuple2.f1;
                    }
                });

        // 分配水印
        source.assignTimestampsAndWatermarks(ws)
                // 映射处理
                .map(new MapFunction<Tuple2<String,Long>,Tuple2<String,Integer>>(){
                    @Override
                    public Tuple2<String, Integer> map(Tuple2<String, Long> stringLongTuple2) throws Exception {
                        FastDateFormat format = FastDateFormat.getInstance("yyyy-MM-dd HH:mm:ss") ;
                        System.out.println("key:" + stringLongTuple2.f0 + " timestamp:" + format.format(stringLongTuple2.f1));
                        return new Tuple2<>(stringLongTuple2.f0, 1);
                    }
                })
                // 分区
                .keyBy(key -> key.f0)
                // 处理函数
                .process(new KeyedProcessFunction<String, Tuple2<String, Integer>, Tuple2<String, Long>>(){

                    // 1、首先声明状态变量
                    ValueState<Long> vs = null;

                    // 2、状态的引用
                    @Override
                    public void open(Configuration parameters) throws Exception {
                        super.open(parameters);
                        // 2.1 构造状态的描述符
                        ValueStateDescriptor<Long> value = new ValueStateDescriptor<>("value", Long.class);
                        // 2.2 生成状态
                        vs = getRuntimeContext().getState(value);
                    }

                    // 每来要给元素都会调用processElement，
                    @Override
                    public void processElement(Tuple2<String, Integer> value, KeyedProcessFunction<String, Tuple2<String, Integer>, Tuple2<String, Long>>.Context ctx, Collector<Tuple2<String, Long>> out) throws Exception {
                        // 对于事件时间，ctx.timestamp()的返回值就是每个元素的extractTimestamp
                        // 对于处理事件，ctx.timestamp()的返回值就是等于此时此刻处理时的事件，System.currentTimeMillis()
                        // 表示我当前正在处理元素的时间戳，new Tuple2<>("张三", System.currentTimeMillis()));
                        long lastTime = ctx.timestamp();

                        // 按照业务要求设置一个事件间隔
                        long timeTimer = lastTime + 3000;
                        vs.update(timeTimer);
                        ctx.timerService().registerEventTimeTimer(timeTimer);
                    }

                    // onTimer方法中的timestamp指的时注册定时器里的时间
                    @Override
                    public void onTimer(long timestamp, KeyedProcessFunction<String, Tuple2<String, Integer>, Tuple2<String, Long>>.OnTimerContext ctx, Collector<Tuple2<String, Long>> out) throws Exception {
                        super.onTimer(timestamp, ctx, out);
                        Long value = vs.value();

                        if(timestamp == value){
                            out.collect(Tuple2.of(ctx.getCurrentKey(), timestamp));
                        }
                    }
                }).print();
        env.execute();
    }
}

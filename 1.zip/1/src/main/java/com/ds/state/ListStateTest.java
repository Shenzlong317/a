package com.ds.state;

import org.apache.flink.api.common.eventtime.SerializableTimestampAssigner;
import org.apache.flink.api.common.eventtime.WatermarkStrategy;
import org.apache.flink.api.common.state.ListState;
import org.apache.flink.api.common.state.ListStateDescriptor;
import org.apache.flink.api.common.state.ValueState;
import org.apache.flink.api.common.state.ValueStateDescriptor;
import org.apache.flink.api.java.tuple.Tuple3;
import org.apache.flink.configuration.Configuration;
import org.apache.flink.streaming.api.datastream.DataStreamSource;
import org.apache.flink.streaming.api.environment.StreamExecutionEnvironment;
import org.apache.flink.streaming.api.functions.KeyedProcessFunction;
import org.apache.flink.streaming.api.functions.source.SourceFunction;
import org.apache.flink.util.Collector;

import java.text.SimpleDateFormat;
import java.time.Duration;
import java.util.Iterator;
import java.util.Random;

public class ListStateTest {
    public static void main(String[] args) throws Exception {
        StreamExecutionEnvironment env = StreamExecutionEnvironment.getExecutionEnvironment();

        DataStreamSource<Tuple3<String, String, Long>> source = env.addSource(new SourceFunction<Tuple3<String, String, Long>>() {
            boolean flag = true;

            @Override
            public void run(SourceContext<Tuple3<String, String, Long>> ctx) throws Exception {
                String[] s = {"张三", "王五", "李四", "赵六"};
                String[] s1 = {"登录", "退出", "加购", "购买"};
                while (flag) {
                    Thread.sleep(1000);
                    int i = new Random().nextInt(4);
                    ctx.collect(new Tuple3<>(s[i], s1[i], System.currentTimeMillis()));
                }
            }

            @Override
            public void cancel() {
                flag = false;
            }
        });

        WatermarkStrategy<Tuple3<String, String, Long>> ws = WatermarkStrategy.<Tuple3<String, String, Long>>forBoundedOutOfOrderness(Duration.ofSeconds(3))
                .withTimestampAssigner(new SerializableTimestampAssigner<Tuple3<String, String, Long>>() {
                    @Override
                    public long extractTimestamp(Tuple3<String, String, Long> stringStringLongTuple3, long l) {
                        return stringStringLongTuple3.f2;
                    }
                });

        source.assignTimestampsAndWatermarks(ws).
                keyBy(key -> key.f0)
                .process(new KeyedProcessFunction<String, Tuple3<String, String, Long>, String>() {
                    ListState<String> ls = null;

                    final long interval = 10000;

                    @Override
                    public void open(Configuration parameters) throws Exception {
                        super.open(parameters);
                        ListStateDescriptor<String> list = new ListStateDescriptor<>("list", String.class);
                        ls = getRuntimeContext().getListState(list);
                    }

                    @Override
                    public void processElement(Tuple3<String, String, Long> value, KeyedProcessFunction<String, Tuple3<String, String, Long>, String>.Context ctx, Collector<String> out) throws Exception {
                        ls.add(value.toString());
                        ctx.timerService().registerEventTimeTimer(ctx.timestamp() + interval);
                    }

                    @Override
                    public void onTimer(long timestamp, KeyedProcessFunction<String, Tuple3<String, String, Long>, String>.OnTimerContext ctx, Collector<String> out) throws Exception {
                        super.onTimer(timestamp, ctx, out);
                        StringBuilder sb = new StringBuilder();
                        Iterable<String> strings = ls.get();
                        if(strings != null){
                            Iterator<String> iterator = strings.iterator();
                            while (iterator.hasNext()){
                                sb.append(iterator.next()).append(",");
                            }
                        }
                        out.collect(ctx.getCurrentKey() + "-----" + sb.toString());
                    }
                })
                .print();

        env.execute();
    }
}

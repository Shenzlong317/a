package com.ds.state;

import org.apache.flink.api.common.state.*;
import org.apache.flink.api.common.typeinfo.Types;
import org.apache.flink.api.java.tuple.Tuple2;
import org.apache.flink.api.java.tuple.Tuple3;
import org.apache.flink.configuration.CheckpointingOptions;
import org.apache.flink.configuration.Configuration;
import org.apache.flink.streaming.api.CheckpointingMode;
import org.apache.flink.streaming.api.datastream.BroadcastConnectedStream;
import org.apache.flink.streaming.api.datastream.BroadcastStream;
import org.apache.flink.streaming.api.datastream.DataStreamSource;
import org.apache.flink.streaming.api.datastream.SingleOutputStreamOperator;
import org.apache.flink.streaming.api.environment.CheckpointConfig;
import org.apache.flink.streaming.api.environment.ExecutionCheckpointingOptions;
import org.apache.flink.streaming.api.environment.StreamExecutionEnvironment;
import org.apache.flink.streaming.api.functions.co.BaseBroadcastProcessFunction;
import org.apache.flink.streaming.api.functions.co.BroadcastProcessFunction;
import org.apache.flink.streaming.api.functions.co.KeyedBroadcastProcessFunction;
import org.apache.flink.streaming.api.functions.source.SourceFunction;
import org.apache.flink.util.Collector;

import java.time.Duration;
import java.util.Random;

public class OperatorBroadcastStateDemo {
    public static void main(String[] args) throws Exception {
        StreamExecutionEnvironment env = StreamExecutionEnvironment.getExecutionEnvironment();
        env.setParallelism(2);

        // 每隔1000 ms进行启动一个检查点【设置checkpoint的周期】，单位是毫秒
        env.enableCheckpointing(1000);

        // 高级选项：
        // 设置模式为exactly-once （这是默认值）
//        env.getCheckpointConfig().setCheckpointingMode(CheckpointingMode.EXACTLY_ONCE);

        // 确保检查点之间有至少500 ms的间隔【checkpoint最小间隔】，这就意味着即使已经达到了周期触发的时间点，只要距离上一个检查点完成的间隔不够，就依然不能开启下一次检查点的保存。这就为正常处理数据留下了充足的间隙。当指定这个参数时，实际并发为1。
        env.getCheckpointConfig().setMinPauseBetweenCheckpoints(500);

        // 检查点必须在一分钟内完成，或者被丢弃【checkpoint的超时时间】，单位是毫秒
        env.getCheckpointConfig().setCheckpointTimeout(60000);

        // 同一时间只允许进行一个检查点
        env.getCheckpointConfig().setMaxConcurrentCheckpoints(1);

        // 设置可以容忍检查点连续失败的次数，默认为0，这意味着不能容忍检查点失败，并且作业将在第一次报告检查点失败时失败。
        env.getCheckpointConfig().setTolerableCheckpointFailureNumber(2);

        // 表示一旦Flink程序被cancel后，会保留Checkpoint数据，以便根据实际需要恢复到指定的Checkpoint,其中：
        // ExternalizedCheckpointCleanup.RETAIN_ON_CANCELLATION:表示一旦Flink处理程序被cancel后，会保留Checkpoint数据，以便根据实际需要恢复到指定的Checkpoint
        // ExternalizedCheckpointCleanup.DELETE_ON_CANCELLATION: 表示一旦Flink处理程序被cancel后，会删除Checkpoint数据，只有job执行失败的时候才会保存checkpoint
        env.getCheckpointConfig().enableExternalizedCheckpoints(CheckpointConfig.ExternalizedCheckpointCleanup.RETAIN_ON_CANCELLATION);

        // 开启UC，这个设置要求检查点模式（CheckpointingMode）必须为exctly-once，并且最大并发的检查点个数为1。
        // env.getCheckpointConfig().enableUnalignedCheckpoints();

        // 开启非对齐检查点才生效：默认0，表示一开始就直接用 非对齐的检查点，如果大于0，一开始用 对齐的检查点（barrier对齐），对齐的时间超过这个参数，自动切换成 非对齐检查点（barrier非对齐）
        // env.getCheckpointConfig().setAlignedCheckpointTimeout(Duration.ofSeconds(1));

        // 设置检查点的位置
        env.getCheckpointConfig().setCheckpointStorage("hdfs:///tmp/my/ck/");

        // 对于已经完成的任务，已经可以做检查点
//        Configuration config = new Configuration();
//        config.set(ExecutionCheckpointingOptions.ENABLE_CHECKPOINTS_AFTER_TASKS_FINISH, true);
//        env.configure(config);
// 说明：如果数据源是有界的，就可能出现部分Task已经处理完所有数据，变成finished状态，不继续工作。从 Flink 1.14 开始，这些finished状态的Task，也可以继续执行检查点。自 1.15 起默认启用此功能，并且可以通过功能标志禁用它
        Configuration config = new Configuration();
        config.set(CheckpointingOptions.MAX_RETAINED_CHECKPOINTS, 20);
        env.configure(config);


        DataStreamSource<Tuple3<String, Integer, Long>> source = env.addSource(new SourceFunction<Tuple3<String, Integer, Long>>() {
            boolean flag = true;

            @Override
            public void run(SourceContext<Tuple3<String, Integer, Long>> ctx) throws Exception {
                String[] str = {"水阀1", "水阀2", "水阀3"};
                while (flag) {
                    int i = new Random().nextInt(3);
                    // 温度
                    int temperature = new Random().nextInt(100);
                    Thread.sleep(1000L);
                    // 设备号、温度、事件时间
                    ctx.collect(new Tuple3<>(str[i], temperature, System.currentTimeMillis()));
                }
            }

            @Override
            public void cancel() {
                flag = false;
            }
        });

        // 配置流（用来广播配置）
        DataStreamSource<String> configDS = env.socketTextStream("ds-bigdata-005", 9876);

        // 1、配置流广播
        MapStateDescriptor<String, Integer> broadcastMapState = new MapStateDescriptor<>("broadcast-state", Types.STRING, Types.INT);
        BroadcastStream<String> configBS = configDS.broadcast(broadcastMapState);

        // 2、把数据流和广播后的配置流 connect
        BroadcastConnectedStream<Tuple3<String, Integer, Long>, String> sensorBCS = source.connect(configBS);

        // 3、调用 process
        sensorBCS.process(new BroadcastProcessFunction<Tuple3<String, Integer, Long>, String, String>() {
                              /**
                               * 数据流的处理方法： 数据流 只能 读取 广播状态，不能修改
                               */
                              @Override
                              public void processElement(Tuple3<String, Integer, Long> value, BroadcastProcessFunction<Tuple3<String, Integer, Long>, String, String>.ReadOnlyContext ctx, Collector<String> out) throws Exception {
                                  // 5、通过上下文获取广播状态，取出里面的值（只读，不能修改）
                                  ReadOnlyBroadcastState<String, Integer> broadcastState = ctx.getBroadcastState(broadcastMapState);
                                  Integer threshold = broadcastState.get("threshold");
                                  // 判断广播状态里是否有数据，因为刚启动时，可能是数据流的第一条数据先来
                                  threshold = (threshold == null ? 0 : threshold);
                                  if (value.f1 > threshold) {
                                      out.collect(value + ",水位超过指定的阈值：" + threshold + "!!!");
                                  }
                              }

                              /**
                               * 广播后的配置流的处理方法:  只有广播流才能修改 广播状态
                               */
                              @Override
                              public void processBroadcastElement(String value, Context ctx, Collector<String> out) throws Exception {
                                  // 4、通过上下文获取广播状态，往里面写数据
                                  BroadcastState<String, Integer> broadcastState = ctx.getBroadcastState(broadcastMapState);
                                  broadcastState.put("threshold", Integer.valueOf(value));

                              }
                          }

                )
                .print();

        env.execute();
    }
}
package com.ds.wm;

import com.alibaba.fastjson2.JSONObject;
import org.apache.flink.streaming.api.functions.source.RichParallelSourceFunction;
import org.apache.flink.streaming.api.watermark.Watermark;

import java.util.Random;

public class DataGenerateSource extends RichParallelSourceFunction<String> {

    private boolean running = true;

    @Override
    public void run(SourceContext ctx) throws Exception {
        while (running){
            Random random = new Random();
            JSONObject data = new JSONObject();
            data.put("key1", random.nextInt());
            data.put("key2", random.nextDouble());
            data.put("key3", random.nextInt());
            // {"key1":-304941093,"key2":0.8784741532941568,"key3":-96739374}
            ctx.collect(data.toJSONString());

            //
            // ctx.collectWithTimestamp(data.toJSONString(), Long.valueOf(System.currentTimeMillis()));
            ctx.emitWatermark(new Watermark(Long.valueOf(System.currentTimeMillis())));

        }
    }

    @Override
    public void cancel() {
        running = false;
    }
}

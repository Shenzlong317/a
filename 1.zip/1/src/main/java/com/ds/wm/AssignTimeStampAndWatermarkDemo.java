package com.ds.wm;

import org.apache.flink.api.common.eventtime.SerializableTimestampAssigner;
import org.apache.flink.api.common.eventtime.WatermarkStrategy;
import org.apache.flink.api.common.typeinfo.Types;
import org.apache.flink.api.java.tuple.Tuple2;
import org.apache.flink.streaming.api.TimeCharacteristic;
import org.apache.flink.streaming.api.environment.StreamExecutionEnvironment;

public class AssignTimeStampAndWatermarkDemo {
    public static void main(String[] args) throws Exception{
        StreamExecutionEnvironment env = StreamExecutionEnvironment.getExecutionEnvironment();
        env.setStreamTimeCharacteristic(TimeCharacteristic.IngestionTime);
        // 生成水印策略
        WatermarkStrategy<Tuple2<Long, String>> ws = WatermarkStrategy.<Tuple2<Long, String>>forMonotonousTimestamps()
                // 填充水印时间
                .withTimestampAssigner(new SerializableTimestampAssigner<Tuple2<Long, String>>() {

                                           @Override
                                           public long extractTimestamp(Tuple2<Long, String> element, long recordTimestamp) {
                                               return element.f0;
                                           }
                                       }
                );


        env.socketTextStream("ds-bigdata-005",9876)
                .map(value -> {
                    String[] s = value.split(" ");
                    return Tuple2.of(Long.parseLong(s[0]),s[1]);
                })
                .returns(Types.TUPLE(Types.LONG,Types.STRING))
                .assignTimestampsAndWatermarks(ws)
                .print();
        env.execute();
    }

}

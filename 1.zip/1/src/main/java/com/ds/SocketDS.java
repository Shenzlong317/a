package com.ds;

import org.apache.flink.api.common.functions.FlatMapFunction;
import org.apache.flink.api.common.typeinfo.TypeHint;
import org.apache.flink.api.common.typeinfo.TypeInformation;
import org.apache.flink.api.common.typeinfo.Types;
import org.apache.flink.api.java.functions.KeySelector;
import org.apache.flink.api.java.tuple.Tuple2;
import org.apache.flink.configuration.Configuration;
import org.apache.flink.configuration.TaskManagerOptions;
import org.apache.flink.streaming.api.TimeCharacteristic;
import org.apache.flink.streaming.api.datastream.DataStreamSource;
import org.apache.flink.streaming.api.datastream.SingleOutputStreamOperator;
import org.apache.flink.streaming.api.environment.StreamExecutionEnvironment;
import org.apache.flink.util.Collector;

public class SocketDS {
    public static void main(String[] args) throws Exception {
        Configuration configuration = new Configuration();

        //1、获取环境SparkContext、SparkSession
        StreamExecutionEnvironment env = StreamExecutionEnvironment.getExecutionEnvironment(configuration);
        //2、加载数据源（Source）
        DataStreamSource<String> source = env.socketTextStream("ds-bigdata-005", 9876);

        //3、转换（Transformation）
        SingleOutputStreamOperator<Tuple2<String, Long>> sum = source.flatMap((String value, Collector<Tuple2<String, Long>> out) -> {
                    String[] s = value.split(" ");
                    for (String str : s) {
                        // Hello World
                        // （Hello，1）
                        // （World，1）
                        out.collect(Tuple2.of(str, 1L));
                    }
                })
//                .returns(Types.TUPLE(Types.STRING, Types.LONG))
//                .returns(Types.TUPLE(Types.STRING, Types.LONG))
//                .returns(new TypeHint<Tuple2<String, Long>>() {})
                .returns(TypeInformation.of(new TypeHint<Tuple2<String, Long>>() {}))
                .keyBy(value -> value.f0)
                .sum(1);

        //4、输出（Sink）
        sum.print();

        //5、手动开启执行execute
        env.execute();
    }
}
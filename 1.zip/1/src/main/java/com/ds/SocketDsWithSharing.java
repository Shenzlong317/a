package com.ds;

import org.apache.flink.api.common.typeinfo.Types;
import org.apache.flink.api.java.tuple.Tuple2;
import org.apache.flink.configuration.Configuration;
import org.apache.flink.configuration.TaskManagerOptions;
import org.apache.flink.streaming.api.datastream.DataStreamSource;
import org.apache.flink.streaming.api.datastream.SingleOutputStreamOperator;
import org.apache.flink.streaming.api.environment.StreamExecutionEnvironment;
import org.apache.flink.util.Collector;

public class SocketDsWithSharing {
    public static void main(String[] args) throws Exception {
        Configuration configuration = new Configuration();
        configuration.setInteger(TaskManagerOptions.NUM_TASK_SLOTS,9);


        //1、获取环境SparkContext、SparkSession
        StreamExecutionEnvironment env = StreamExecutionEnvironment.getExecutionEnvironment(configuration);
//        env.setParallelism(4);

        //2、加载数据源（Source）
        //socket source 不支持并行度，所以只能有一个并行度
        DataStreamSource<String> source = env.socketTextStream("ds-bigdata-005", 9876);

    //3、转换（Transformation）
        SingleOutputStreamOperator<Tuple2<String, Long>> sum = source.flatMap((String value, Collector<Tuple2<String, Long>> out) -> {
                    String[] s = value.split(" ");
                    for (String str : s) {
                        // Hello World
                        // （Hello，1）
                        // （World，1）
                        out.collect(Tuple2.of(str, 1L));
                    }
                }).slotSharingGroup("flatMap")
                .returns(Types.TUPLE(Types.STRING, Types.LONG))
                // keyBy原则不能看作是运算算子，算子分成两类：一类是路由算子，另外一类是运算算子，只有运算算子才能设置并行度
                // keyBy会和后面的聚合算子绑定在一起，形成KeyedAggregatation算子
                .keyBy(value -> value.f0)
                .sum(1).slotSharingGroup("sum");
        // socket:default(1)
        // flatMap:flatMap(4)
        // sum-> print:sum(4)
        // 1 + 4 + 4 =9

        //4、输出（Sink）
        sum.print().setParallelism(1);
        //5、手动开启执行execute
        env.execute();
    }
}


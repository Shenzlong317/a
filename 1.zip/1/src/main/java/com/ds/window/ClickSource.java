package com.ds.window;

import com.ds.operator.transformation.EventRecord;
import org.apache.flink.streaming.api.functions.source.SourceFunction;

import java.util.Calendar;
import java.util.Random;

public class ClickSource implements SourceFunction<EventRecord> {
    private boolean running = true;

    Random random = new Random();

    String[] users ={"Mary","Bob","Candy","Lily","Xiaohong"};
    String[] urls = {"./home/","./cart","./prod?id=100","/prod?id=200","./fav"};


    @Override
    public void run(SourceContext<EventRecord> ctx) throws Exception {
        while (running){
            String user = users[random.nextInt(users.length)];
            String url = urls[random.nextInt(urls.length)];
            long timestamp = Calendar.getInstance().getTimeInMillis();
            ctx.collect(new EventRecord(user, url, timestamp));
            Thread.sleep(1000L);
        }
    }

    @Override
    public void cancel() {
        running = false;
    }
}

package com.ds.window;

import com.ds.operator.transformation.EventRecord;
import org.apache.flink.api.common.eventtime.SerializableTimestampAssigner;
import org.apache.flink.api.common.eventtime.WatermarkStrategy;
import org.apache.flink.api.common.functions.ReduceFunction;
import org.apache.flink.api.common.typeinfo.Types;
import org.apache.flink.api.java.tuple.Tuple2;
import org.apache.flink.streaming.api.datastream.DataStream;
import org.apache.flink.streaming.api.environment.StreamExecutionEnvironment;
import org.apache.flink.streaming.api.windowing.assigners.TumblingEventTimeWindows;
import org.apache.flink.streaming.api.windowing.time.Time;

import java.time.Duration;

public class WindowReduceDemo {
    public static void main(String[] args) throws Exception {
        StreamExecutionEnvironment env = StreamExecutionEnvironment.getExecutionEnvironment();
        env.setParallelism(1);

        WatermarkStrategy<EventRecord> ws = WatermarkStrategy.<EventRecord>forBoundedOutOfOrderness(Duration.ofSeconds(5))
                .withTimestampAssigner(new SerializableTimestampAssigner<EventRecord>() {
                    @Override
                    public long extractTimestamp(EventRecord element, long recordTimestamp) {
                        return element.getTs();
                    }
                });


        // 读取数据，并提取时间戳、生成水位线
        env.fromElements(
                new EventRecord("Mary", "./home", 1000L),
                new EventRecord("Bob", "./cart", 2000L),
                new EventRecord("Alice", "./prod?id=100", 3000L),
                new EventRecord("Alice", "./prod?id=200", 3500L),
                new EventRecord("Bob", "/prod?id=2", 2500L),
                new EventRecord("Alice", "./prod?id=300", 3600L),
                new EventRecord("Bob", "./home", 3000L),
                new EventRecord("Bob", "./prod?id=1", 2300L),
                new EventRecord("Bob", "./prod?id=3", 3300L))
                .assignTimestampsAndWatermarks(ws)
                // 统计当前5s内点击次数最多的用户使用
                // new EventRecord("Mary", "./home", 1000L) => Tuple2.of("Mary",1L)
                .map(value -> Tuple2.of(value.getName(),1L))
                .returns(Types.TUPLE(Types.STRING,Types.LONG))
                .keyBy(key -> key.f0)
                .window(TumblingEventTimeWindows.of(Time.seconds(5)))
                .reduce(new ReduceFunction<Tuple2<String, Long>>() {
                    @Override
                    public Tuple2<String, Long> reduce(Tuple2<String, Long> value1, Tuple2<String, Long> value2) throws Exception {
                        return Tuple2.of(value1.f0, value1.f1+ value2.f1);
                    }
                })
                .print();

        env.execute();

    }
}


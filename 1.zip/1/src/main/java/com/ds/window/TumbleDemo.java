package com.ds.window;

import org.apache.flink.api.common.eventtime.SerializableTimestampAssigner;
import org.apache.flink.api.common.eventtime.WatermarkStrategy;
import org.apache.flink.api.java.tuple.Tuple4;
import org.apache.flink.streaming.api.TimeCharacteristic;
import org.apache.flink.streaming.api.environment.StreamExecutionEnvironment;
import org.apache.flink.streaming.api.functions.sink.PrintSinkFunction;
import org.apache.flink.streaming.api.functions.source.SourceFunction;
import org.apache.flink.streaming.api.windowing.assigners.TumblingEventTimeWindows;
import org.apache.flink.streaming.api.windowing.assigners.TumblingProcessingTimeWindows;
import org.apache.flink.streaming.api.windowing.time.Time;

import java.time.Duration;

public class TumbleDemo {
    public static void main(String[] args) throws Exception{
        StreamExecutionEnvironment env = StreamExecutionEnvironment.getExecutionEnvironment();
        env.setParallelism(1);
//        env.setStreamTimeCharacteristic(TimeCharacteristic.ProcessingTime);

        // 定义完整的水印策略
        WatermarkStrategy<Tuple4<String, String, Integer, Long>> ws = WatermarkStrategy.<Tuple4<String, String, Integer, Long>>forBoundedOutOfOrderness(Duration.ofSeconds(5))
                .withTimestampAssigner(
                        new SerializableTimestampAssigner<Tuple4<String, String, Integer, Long>>() {
                            @Override
                            public long extractTimestamp(Tuple4<String, String, Integer, Long> element, long recordTimestamp) {
                                return element.f3;
                            }
                        }

                );

        env.addSource(new UserDefinedSource())
                // 我们为什么要设置水印：
                // 原因就是因为业务上一般都会使用EventTime窗口作为处理，而水印就是触发事件事件窗口的触发器
                .assignTimestampsAndWatermarks(ws)
                // 做分区
                .keyBy(key -> key.f0)
                // 做窗口
                .window(TumblingProcessingTimeWindows.of(Time.seconds(10)))
                // 默认的flink自带的窗口分配器都实现了触发器
                // .trigger()
                // 驱逐器，可选
                // .evictor()
//                .allowedLateness(Time.seconds(5))
//                .sideOutputLateData()
                // 基于窗口中的数据做聚合巨酸
                .sum(2)
                // 等价于print
                .addSink(new PrintSinkFunction());
        env.execute();
    }
}

class UserDefinedSource implements SourceFunction<Tuple4<String,String,Integer,Long>>{

    private boolean running = true;

    @Override
    public void run(SourceContext<Tuple4<String,String,Integer,Long>> ctx) throws Exception {
        while(running){
            ctx.collect(Tuple4.of("a","b",1,System.currentTimeMillis()));
            Thread.sleep(10L);
        }
    }

    @Override
    public void cancel() {
        running = false;
    }
}

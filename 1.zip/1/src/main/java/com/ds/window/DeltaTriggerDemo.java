package com.ds.window;

import org.apache.flink.api.common.functions.ReduceFunction;
import org.apache.flink.api.common.typeinfo.TypeHint;
import org.apache.flink.api.common.typeinfo.TypeInformation;
import org.apache.flink.api.common.typeinfo.Types;
import org.apache.flink.api.java.tuple.Tuple2;
import org.apache.flink.streaming.api.environment.StreamExecutionEnvironment;
import org.apache.flink.streaming.api.functions.windowing.delta.DeltaFunction;
import org.apache.flink.streaming.api.windowing.assigners.GlobalWindows;
import org.apache.flink.streaming.api.windowing.assigners.TumblingEventTimeWindows;
import org.apache.flink.streaming.api.windowing.triggers.DeltaTrigger;
import org.apache.flink.streaming.api.windowing.windows.Window;
import scala.Int;

public class DeltaTriggerDemo {
    public static void main(String[] args) throws  Exception{
        StreamExecutionEnvironment env = StreamExecutionEnvironment.getExecutionEnvironment();

        DeltaTrigger<Tuple2<String, Integer>, Window> delta = DeltaTrigger.of(2,
                new DeltaFunction<Tuple2<String, Integer>>() {
                    @Override
                    public double getDelta(Tuple2<String, Integer> oldDataPoint, Tuple2<String, Integer> newDataPoint) {
                        return newDataPoint.f1 - oldDataPoint.f1;
                    }
                },
                TypeInformation.of(new TypeHint<Tuple2<String, Integer>>() {
                }).createSerializer(env.getConfig())
        );

        env.socketTextStream("ds-bigdata-005",9876)
                .map(value -> {
                    String[] s = value.split(" ");
                    return Tuple2.of(s[0], Integer.valueOf(s[1]));
                })
                .returns(Types.TUPLE(Types.STRING,Types.INT))
                .keyBy(key -> key.f0)
                .window(GlobalWindows.create())
                .trigger(delta)
                .reduce(new ReduceFunction<Tuple2<String, Integer>>() {
                    @Override
                    public Tuple2<String, Integer> reduce(Tuple2<String, Integer> value1, Tuple2<String, Integer> value2) throws Exception {
                        return Tuple2.of(value1.f0, value1.f1 + value2.f1);
                    }
                })
                .print();

        env.execute();
    }
}

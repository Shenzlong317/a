package com.ds.window;

import com.ds.operator.transformation.EventRecord;
import org.apache.flink.api.common.functions.AggregateFunction;
import org.apache.flink.api.java.tuple.Tuple2;

import java.util.HashSet;

public class AggragatePVUV implements AggregateFunction<EventRecord, Tuple2<Long, HashSet<String>>, Double> {
    @Override
    public Tuple2<Long, HashSet<String>> createAccumulator() {
        return Tuple2.of(0L, new HashSet<>());
    }

    @Override
    public Tuple2<Long, HashSet<String>> add(EventRecord value, Tuple2<Long, HashSet<String>> accumulator) {
        accumulator.f1.add(value.getName());
        return Tuple2.of(accumulator.f0 + 1L,accumulator.f1);
    }

    @Override
    public Double getResult(Tuple2<Long, HashSet<String>> accumulator) {
        return (double) accumulator.f0 / accumulator.f1.size();
    }

    @Override
    public Tuple2<Long, HashSet<String>> merge(Tuple2<Long, HashSet<String>> a, Tuple2<Long, HashSet<String>> b) {
        return null;
    }
}
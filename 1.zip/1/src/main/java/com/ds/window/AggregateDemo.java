package com.ds.window;

import com.ds.operator.transformation.EventRecord;
import org.apache.flink.api.common.eventtime.SerializableTimestampAssigner;
import org.apache.flink.api.common.eventtime.WatermarkStrategy;
import org.apache.flink.streaming.api.datastream.DataStream;
import org.apache.flink.streaming.api.environment.StreamExecutionEnvironment;
import org.apache.flink.streaming.api.windowing.assigners.SlidingEventTimeWindows;
import org.apache.flink.streaming.api.windowing.time.Time;

import java.time.Duration;

public class AggregateDemo {
    public static void main(String[] args) throws Exception{
        StreamExecutionEnvironment env = StreamExecutionEnvironment.getExecutionEnvironment();
        env.setParallelism(1);
        // 读取数据，并提取时间戳、生成水位线
        DataStream<EventRecord> stream = env.addSource(new ClickSource())
                .assignTimestampsAndWatermarks(WatermarkStrategy.<EventRecord>forBoundedOutOfOrderness(Duration.ZERO)
                        .withTimestampAssigner(new SerializableTimestampAssigner<EventRecord>() {
                            @Override
                            public long extractTimestamp(EventRecord element, long recordTimestamp) {
                                return element.getTs();
                            }
                        }));

        // stream.print("data");
        stream.keyBy(key -> true)
              .window(SlidingEventTimeWindows.of(Time.seconds(10),Time.seconds(2)))
              .aggregate(new AggragatePVUV())
              .print();
        env.execute();
    }
}

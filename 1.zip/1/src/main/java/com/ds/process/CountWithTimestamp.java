package com.ds.process;

public class CountWithTimestamp {
    public String key;

    public long count;

    public long lastModified;
}

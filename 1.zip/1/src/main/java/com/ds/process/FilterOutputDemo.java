package com.ds.process;

import org.apache.flink.api.common.typeinfo.Types;
import org.apache.flink.api.java.tuple.Tuple2;
import org.apache.flink.streaming.api.datastream.DataStreamSource;
import org.apache.flink.streaming.api.datastream.SingleOutputStreamOperator;
import org.apache.flink.streaming.api.environment.StreamExecutionEnvironment;
import org.apache.flink.streaming.api.functions.ProcessFunction;
import org.apache.flink.util.Collector;
import org.apache.flink.util.OutputTag;

public class FilterOutputDemo {
    public static void main(String[] args) throws  Exception{
        StreamExecutionEnvironment env = StreamExecutionEnvironment.getExecutionEnvironment();
        DataStreamSource<Tuple2<Integer, Integer>> dataDS = env.fromElements(
                Tuple2.of(1, 22),
                Tuple2.of(1, 24),
                Tuple2.of(2, 0),
                Tuple2.of(2, 7),
                Tuple2.of(3, 7));

        OutputTag<Tuple2<Integer, Integer>> one = new OutputTag<>("one", Types.TUPLE(Types.INT, Types.INT));
        OutputTag<Tuple2<Integer, Integer>> two = new OutputTag<>("two", Types.TUPLE(Types.INT, Types.INT));


        SingleOutputStreamOperator<Tuple2<Integer, Integer>> process = dataDS.process(new ProcessFunction<Tuple2<Integer, Integer>, Tuple2<Integer, Integer>>() {
            @Override
            public void processElement(Tuple2<Integer, Integer> value, ProcessFunction<Tuple2<Integer, Integer>, Tuple2<Integer, Integer>>.Context ctx, Collector<Tuple2<Integer, Integer>> out) throws Exception {
                if (value.f0 == 1) {
                    ctx.output(one, value);
                } else if (value.f0 == 2) {
                    ctx.output(two, value);
                } else {
                    out.collect(value);
                }
            }
        });

//        process.print();
        process.getSideOutput(one).print();
//        process.getSideOutput(two).print();

        env.execute();
    }
}

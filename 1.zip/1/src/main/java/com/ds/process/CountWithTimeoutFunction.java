package com.ds.process;

import org.apache.flink.api.common.state.ValueState;
import org.apache.flink.api.common.state.ValueStateDescriptor;
import org.apache.flink.api.java.tuple.Tuple2;
import org.apache.flink.configuration.Configuration;
import org.apache.flink.streaming.api.functions.KeyedProcessFunction;
import org.apache.flink.util.Collector;

public class CountWithTimeoutFunction extends KeyedProcessFunction<String, Tuple2<String, Integer>, Tuple2<String, Long>> {

    // 定义状态
    private ValueState<CountWithTimestamp> state;

    // 初始化状态
    @Override
    public void open(Configuration parameters) throws Exception {
        state = getRuntimeContext().getState(new ValueStateDescriptor<>("myState",CountWithTimestamp.class));
    }

    @Override
    public void processElement(Tuple2<String, Integer> value, KeyedProcessFunction<String, Tuple2<String, Integer>, Tuple2<String, Long>>.Context ctx, Collector<Tuple2<String, Long>> out) throws Exception {
        // 获取当前元素的key
        String currentKey = ctx.getCurrentKey();

        // 获取状态
        CountWithTimestamp current = state.value();

        // 第一次处理的时候状态为空
        if( current == null){
            current = new CountWithTimestamp();
            current.key = value.f0;
        }

        current.count++;
        current.lastModified = System.currentTimeMillis();

        state.update(current);

        long timer = current.lastModified + 10000;

        ctx.timerService().registerProcessingTimeTimer(timer);

        // 打印所有信息，用于核对数据正确性
        System.out.println(String.format("process, %s, %d, lastModified : %d (%s), timer : %d (%s)\n\n",
                currentKey,
                current.count,
                current.lastModified,
                KeyedProcessFunctionDemo.time(current.lastModified),
                timer,
                KeyedProcessFunctionDemo.time(timer)));

    }

    @Override
    public void onTimer(long timestamp, KeyedProcessFunction<String, Tuple2<String, Integer>, Tuple2<String, Long>>.OnTimerContext ctx, Collector<Tuple2<String, Long>> out) throws Exception {
        // 获取当前元素的key
        String currentKey = ctx.getCurrentKey();

        // 获取状态
        CountWithTimestamp result = state.value();

        boolean isTimeout = false;

        if (timestamp == result.lastModified + 10000){
            out.collect(Tuple2.of(result.key, result.count));
            isTimeout = true;
        }

        // 打印数据，用于核对是否符合预期
        System.out.println(String.format("ontimer, %s, %d, lastModified : %d (%s), stamp : %d (%s), isTimeout : %s\n\n",
                currentKey,
                result.count,
                result.lastModified,
                KeyedProcessFunctionDemo.time(result.lastModified),
                timestamp,
                KeyedProcessFunctionDemo.time(timestamp),
                isTimeout));
    }
}

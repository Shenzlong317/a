package com.ds.process;

import org.apache.flink.api.java.tuple.Tuple2;
import org.apache.flink.streaming.api.datastream.DataStream;
import org.apache.flink.streaming.api.environment.StreamExecutionEnvironment;
import org.apache.flink.streaming.api.functions.ProcessFunction;
import org.apache.flink.util.Collector;

public class ProcessFunctionDemo {
    public static void main(String[] args) throws Exception {
        StreamExecutionEnvironment env = StreamExecutionEnvironment.getExecutionEnvironment();

        DataStream<Tuple2<String, Integer>> dataStream = env.fromElements(
                new Tuple2<>("Alice", 1),
                new Tuple2<>("Bob", 2),
                new Tuple2<>("Alice", 3)
        );

        dataStream.map(data -> data.f0 + "====" + data.f1);

        dataStream.process(new ProcessFunction<Tuple2<String, Integer>, String>() {
            @Override
            public void processElement(Tuple2<String, Integer> value, ProcessFunction<Tuple2<String, Integer>, String>.Context ctx, Collector<String> out) throws Exception {
                out.collect(value.f0 + "===" + value.f1);
            }
        })
                .print();

        env.execute();
    }
}

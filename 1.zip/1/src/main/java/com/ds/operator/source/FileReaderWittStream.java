package com.ds.operator.source;

import org.apache.flink.api.common.io.FilePathFilter;
import org.apache.flink.api.common.io.GlobFilePathFilter;
import org.apache.flink.api.java.io.TextInputFormat;
import org.apache.flink.api.scala.typeutils.Types;
import org.apache.flink.configuration.Configuration;
import org.apache.flink.core.fs.Path;
import org.apache.flink.streaming.api.environment.StreamExecutionEnvironment;
import org.apache.flink.streaming.api.functions.source.FileProcessingMode;

import java.util.Collections;

public class FileReaderWittStream {
    public static void main(String[] args) throws Exception{
        StreamExecutionEnvironment env = StreamExecutionEnvironment.getExecutionEnvironment();
        Configuration configuration = new Configuration();
        configuration.setBoolean("recursive.file.enumeration",true);

        String filePath = "c:/abc/";
        TextInputFormat format = new TextInputFormat(new Path(filePath));
        format.configure(configuration);
        GlobFilePathFilter globFilePathFilter = new GlobFilePathFilter(
                Collections.singletonList("**"),
                Collections.singletonList("c:/abc/1/1.txt")
        );
        format.setFilesFilter(globFilePathFilter);
        env.readFile(format,filePath, FileProcessingMode.PROCESS_CONTINUOUSLY,1000, Types.STRING())
                .print();
        env.execute();
    }
}

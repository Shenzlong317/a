package com.ds.operator.transformation;

import org.apache.flink.api.common.functions.ReduceFunction;
import org.apache.flink.api.common.typeinfo.Types;
import org.apache.flink.api.java.tuple.Tuple3;
import org.apache.flink.streaming.api.environment.StreamExecutionEnvironment;

public class ReduceDemo {
    public static void main(String[] args) throws Exception{
    StreamExecutionEnvironment env = StreamExecutionEnvironment.getExecutionEnvironment();

        env.fromElements(Tuple3.of("zs",5,"w"),
                Tuple3.of("zs",7,"m"),
                Tuple3.of("ww",5, "w"),
                Tuple3.of("ls",3, "w"))
                .keyBy(key -> key.f0)
                .reduce((Tuple3<String, Integer, String> value1, Tuple3<String, Integer, String> value2) -> Tuple3.of(value1.f0, Math.max(value1.f1, value2.f1), value1.f2))
                //.returns(Types.TUPLE(Types.STRING,Types.INT,Types.STRING))
                .print();

        env.execute();
    }
}

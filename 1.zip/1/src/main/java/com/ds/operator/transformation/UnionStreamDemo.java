package com.ds.operator.transformation;

import org.apache.flink.streaming.api.datastream.DataStreamSource;
import org.apache.flink.streaming.api.environment.StreamExecutionEnvironment;

public class UnionStreamDemo {
    public static void main(String[] args) throws Exception{
        StreamExecutionEnvironment env = StreamExecutionEnvironment.getExecutionEnvironment();
        DataStreamSource<Integer> source1 = env.fromElements(1, 2, 3, 4);
        DataStreamSource<Integer> source2 = env.fromElements(11, 22, 33, 44);
        DataStreamSource<String> source3 = env.fromElements("111", "2222", "333", "444");

        source1.union(source2,source3.map(Integer::valueOf))
                .print();

        env.execute();
    }
}

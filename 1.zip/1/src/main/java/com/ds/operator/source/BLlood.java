package com.ds.operator.source;

import java.util.List;

public class BLlood {
    /**
     * output : []
     * input : [{"name":"ds_stu1.pyr_employees"}]
     * driver : {"type":"script","params":"","version":"1","uri":"hive-client","content":"bm8tY29udGVudA==","SCHEDULER_TASK_ID":-1}
     * resource : {"applicationIds":[],"duration":"45ms","endTime":"2024-10-30 22:49:53","jobType":"Hive","startTime":"2024-10-30 22:49:53","usedResources":0}
     * type : hive
     * operation : DESCTABLE
     * user : pyren240131
     * tasks : []
     * sql : DESCRIBE FORMATTED `ds_stu1`.`pyr_employees`
     * timestamp : 1730299793654
     */

    private DriverBean driver;
    private ResourceBean resource;
    private String type;
    private String operation;
    private String user;
    private String sql;
    private long timestamp;
    private List<?> output;
    private List<InputBean> input;
    private List<?> tasks;

    public DriverBean getDriver() {
        return driver;
    }

    public void setDriver(DriverBean driver) {
        this.driver = driver;
    }

    public ResourceBean getResource() {
        return resource;
    }

    public void setResource(ResourceBean resource) {
        this.resource = resource;
    }

    public String getType() {
        return type;
    }

    public void setType(String type) {
        this.type = type;
    }

    public String getOperation() {
        return operation;
    }

    public void setOperation(String operation) {
        this.operation = operation;
    }

    public String getUser() {
        return user;
    }

    public void setUser(String user) {
        this.user = user;
    }

    public String getSql() {
        return sql;
    }

    public void setSql(String sql) {
        this.sql = sql;
    }

    public long getTimestamp() {
        return timestamp;
    }

    public void setTimestamp(long timestamp) {
        this.timestamp = timestamp;
    }

    public List<?> getOutput() {
        return output;
    }

    public void setOutput(List<?> output) {
        this.output = output;
    }

    public List<InputBean> getInput() {
        return input;
    }

    public void setInput(List<InputBean> input) {
        this.input = input;
    }

    public List<?> getTasks() {
        return tasks;
    }

    public void setTasks(List<?> tasks) {
        this.tasks = tasks;
    }

    public static class DriverBean {
        /**
         * type : script
         * params :
         * version : 1
         * uri : hive-client
         * content : bm8tY29udGVudA==
         * SCHEDULER_TASK_ID : -1
         */

        private String type;
        private String params;
        private String version;
        private String uri;
        private String content;
        private int SCHEDULER_TASK_ID;

        public String getType() {
            return type;
        }

        public void setType(String type) {
            this.type = type;
        }

        public String getParams() {
            return params;
        }

        public void setParams(String params) {
            this.params = params;
        }

        public String getVersion() {
            return version;
        }

        public void setVersion(String version) {
            this.version = version;
        }

        public String getUri() {
            return uri;
        }

        public void setUri(String uri) {
            this.uri = uri;
        }

        public String getContent() {
            return content;
        }

        public void setContent(String content) {
            this.content = content;
        }

        public int getSCHEDULER_TASK_ID() {
            return SCHEDULER_TASK_ID;
        }

        public void setSCHEDULER_TASK_ID(int SCHEDULER_TASK_ID) {
            this.SCHEDULER_TASK_ID = SCHEDULER_TASK_ID;
        }
    }

    public static class ResourceBean {
        /**
         * applicationIds : []
         * duration : 45ms
         * endTime : 2024-10-30 22:49:53
         * jobType : Hive
         * startTime : 2024-10-30 22:49:53
         * usedResources : 0.0
         */

        private String duration;
        private String endTime;
        private String jobType;
        private String startTime;
        private double usedResources;
        private List<?> applicationIds;

        public String getDuration() {
            return duration;
        }

        public void setDuration(String duration) {
            this.duration = duration;
        }

        public String getEndTime() {
            return endTime;
        }

        public void setEndTime(String endTime) {
            this.endTime = endTime;
        }

        public String getJobType() {
            return jobType;
        }

        public void setJobType(String jobType) {
            this.jobType = jobType;
        }

        public String getStartTime() {
            return startTime;
        }

        public void setStartTime(String startTime) {
            this.startTime = startTime;
        }

        public double getUsedResources() {
            return usedResources;
        }

        public void setUsedResources(double usedResources) {
            this.usedResources = usedResources;
        }

        public List<?> getApplicationIds() {
            return applicationIds;
        }

        public void setApplicationIds(List<?> applicationIds) {
            this.applicationIds = applicationIds;
        }
    }

    public static class InputBean {
        /**
         * name : ds_stu1.pyr_employees
         */

        private String name;

        public String getName() {
            return name;
        }

        public void setName(String name) {
            this.name = name;
        }
    }
}

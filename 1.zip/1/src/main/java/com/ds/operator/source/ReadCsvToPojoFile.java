package com.ds.operator.source;

import org.apache.flink.api.java.io.PojoCsvInputFormat;
import org.apache.flink.api.java.typeutils.PojoTypeInfo;
import org.apache.flink.api.java.typeutils.TypeExtractor;
import org.apache.flink.core.fs.Path;
import org.apache.flink.streaming.api.environment.StreamExecutionEnvironment;
import org.apache.flink.streaming.api.functions.source.FileProcessingMode;

public class ReadCsvToPojoFile {
    public static void main(String[] args) throws Exception{
        StreamExecutionEnvironment env = StreamExecutionEnvironment.getExecutionEnvironment();
        String filePath = "c://ghi/1.txt";
        PojoTypeInfo<UserBehavior> pojoType =  (PojoTypeInfo<UserBehavior>)TypeExtractor.createTypeInfo(UserBehavior.class);
        String[] fieldNames = new String[]{"userId","itemId","categoryId","behavior","timestamp"};

        PojoCsvInputFormat<UserBehavior> format = new PojoCsvInputFormat<>(new Path(filePath), pojoType, fieldNames);
        format.setDelimiter("@_@");
        format.setFieldDelimiter("||");

        env.readFile(format,filePath, FileProcessingMode.PROCESS_CONTINUOUSLY,1000,pojoType).setParallelism(3)
                .print();

        env.execute();
    }

    // 定义Pojo
    // 要用public修饰，要么是独立的类，要么是静态类
    public static class UserBehavior{
        // 所有的字段要么是public，要么有对应的public的get/set方法
        public long userId;
        public long itemId;
        public int categoryId;
        public String behavior; // pv、cart、fav、buy
        public String timestamp;

        public UserBehavior() {
        }

        @Override
        public String toString() {
            return "UserBehavior{" +
                    "userId=" + userId +
                    ", itemId=" + itemId +
                    ", catagoryId=" + categoryId +
                    ", behaivor='" + behavior + '\'' +
                    ", timestamp='" + timestamp + '\'' +
                    '}';
        }
    }
}





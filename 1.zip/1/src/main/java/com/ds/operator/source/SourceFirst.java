package com.ds.operator.source;

import org.apache.flink.streaming.api.environment.StreamExecutionEnvironment;

public class SourceFirst {
    public static void main(String[] args) throws Exception {
        StreamExecutionEnvironment env = StreamExecutionEnvironment.getExecutionEnvironment();
        // 老的source接口
        env.addSource(new MySourceFunction()).setParallelism(2).print();
        // 新的source接口
//        env.fromSource()
        env.execute();
    }
}


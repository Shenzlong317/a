package com.ds.operator.source;

import org.apache.flink.streaming.api.environment.StreamExecutionEnvironment;

public class FileReader {
    public static void main(String[] args) throws Exception{
        StreamExecutionEnvironment env = StreamExecutionEnvironment.getExecutionEnvironment();
        env.readTextFile("c://ghi/1.txt")
                .print();

        env.execute();
    }
}

package com.ds.operator.transformation;

import org.apache.flink.api.common.functions.FilterFunction;
import org.apache.flink.api.common.functions.MapFunction;
import org.apache.flink.streaming.api.datastream.DataStreamSource;
import org.apache.flink.streaming.api.datastream.IterativeStream;
import org.apache.flink.streaming.api.datastream.SingleOutputStreamOperator;
import org.apache.flink.streaming.api.environment.StreamExecutionEnvironment;

public class IteratorStream {
    public static void main(String[] args) throws Exception {
        // 获取执行环境
        StreamExecutionEnvironment env = StreamExecutionEnvironment.getExecutionEnvironment();

        // 从端口获取数据
        DataStreamSource<String> line = env.socketTextStream("ds-bigdata-005", 9876);

        // 将数据转换为long
        SingleOutputStreamOperator<Long> longStream = line.map(Long::parseLong);

        // 使用迭代计算
        IterativeStream<Long> iterativeStream = longStream.iterate();

        // 迭代中进行的计算,表明每次迭代要干的事情
        SingleOutputStreamOperator<Long> streamOperator = iterativeStream.map(new MapFunction<Long, Long>() {
            @Override
            public Long map(Long input) throws Exception {
                return input - 1;
            }
        });

        // 添加迭代终止的条件
        SingleOutputStreamOperator<Long> closeFilter = streamOperator.filter(new FilterFunction<Long>() {
            @Override
            public boolean filter(Long input) throws Exception {
                return input > 0;
            }
        });

        iterativeStream.closeWith(closeFilter);



        // 输出大于0的结果
        streamOperator.filter(e -> e > 0).print();

        env.execute("iterate");
    }
}

package com.ds.operator.sink;

import org.apache.flink.api.common.typeinfo.TypeInformation;
import org.apache.flink.configuration.Configuration;
import org.apache.flink.streaming.api.environment.StreamExecutionEnvironment;
import org.apache.flink.streaming.api.functions.sink.RichSinkFunction;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;

public class CustomSink {
    public static void main(String[] args) throws Exception{
        StreamExecutionEnvironment env = StreamExecutionEnvironment.getExecutionEnvironment();
        env.socketTextStream("ds-bigdata-005", 9876)
                .map(value -> {
                    String[] s = value.split(" ");
                    return new Student(Integer.valueOf(s[0]),s[1],Integer.valueOf(s[2]));
                })
                .returns(TypeInformation.of(Student.class))
                .addSink(new MySink());

        env.execute();
    }
}

class MySink extends RichSinkFunction<Student>{
    Connection connection;
    PreparedStatement pstm;


    @Override
    public void open(Configuration parameters) throws Exception {
        super.open(parameters);
        try{
            Class.forName("com.mysql.jdbc.Driver");
            String urlStr = "jdbc:mysql://ds-bigdata-001:3306/ds_test";
            connection = DriverManager.getConnection(urlStr,"ds_read","ds#readA0906");
        }catch (Exception e){
            e.getMessage();
        }
        String sqlStr = "insert into student1(id,name,age) values (?,?,?)";
        pstm = connection.prepareStatement(sqlStr);
    }

    @Override
    public void invoke(Student value, Context context) throws Exception {
        pstm.setInt(1,value.getId());
        pstm.setString(2,value.getName());
        pstm.setInt(3,value.getAge());
        pstm.executeUpdate();
    }

    @Override
    public void close() throws Exception {
        super.close();
        if(pstm != null){
            pstm.close();
        }
        if(connection != null){
            connection.close();
        }
    }
}



package com.ds.operator.transformation;

import org.apache.flink.api.common.functions.MapFunction;
import org.apache.flink.streaming.api.environment.StreamExecutionEnvironment;

public class MapDemo {
    public static void main(String[] args) throws Exception{
        StreamExecutionEnvironment env = StreamExecutionEnvironment.getExecutionEnvironment();

//        MapFunction mapper = new MyMapFunction();
//        env.fromElements(1,2,3,4,5)
//                .map(mapper)
//                .print();
        // 第二种方式：使用匿名内部内
//        env.fromElements(1,2,3,4,5)
//                .map(new MapFunction<Integer, Integer>() {
//                    @Override
//                    public Integer map(Integer value) throws Exception {
//                        return value + 10;
//                    }
//                })
//                .print();

        // 第三种方法：lambda函数
        env.fromElements(1,2,3,4,5)
                .map(value -> value + 10)
                .print();

        env.execute();
    }
}

// 显示声明
class MyMapFunction implements MapFunction<Integer, Integer> {

    @Override
    public Integer map(Integer value) throws Exception {
        return value + 10;
    }
}

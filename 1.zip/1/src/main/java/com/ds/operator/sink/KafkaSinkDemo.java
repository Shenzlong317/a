package com.ds.operator.sink;

import org.apache.flink.api.common.serialization.SimpleStringSchema;
import org.apache.flink.api.common.typeinfo.Types;
import org.apache.flink.connector.base.DeliveryGuarantee;
import org.apache.flink.connector.kafka.sink.KafkaRecordSerializationSchema;
import org.apache.flink.connector.kafka.sink.KafkaSink;
import org.apache.flink.streaming.api.datastream.SingleOutputStreamOperator;
import org.apache.flink.streaming.api.environment.StreamExecutionEnvironment;
import org.apache.flink.streaming.api.functions.source.datagen.DataGeneratorSource;
import org.apache.flink.streaming.api.functions.source.datagen.RandomGenerator;
import org.apache.kafka.clients.producer.ProducerConfig;

import java.util.Properties;

public class KafkaSinkDemo {
    public static void main(String[] args) throws Exception{
        StreamExecutionEnvironment env = StreamExecutionEnvironment.getExecutionEnvironment();
        SingleOutputStreamOperator<String> source = env.addSource(new DataGeneratorSource<String>(RandomGenerator.stringGenerator(10)))
                .returns(Types.STRING);

        Properties properties = new Properties();
//        properties.setProperty(ProducerConfig.TRANSACTION_TIMEOUT_CONFIG,10*60*1000 + "");



        KafkaSink<String> kafkaSink = KafkaSink.<String>builder()
                .setBootstrapServers("ds-bigdata-002:9092,ds-bigdata-003:9092,ds-bigdata-004:9092,")
                .setRecordSerializer(
                        KafkaRecordSerializationSchema.builder()
                                .setTopic("ds-flink2")
                                .setValueSerializationSchema(new SimpleStringSchema())
                                .build()

                )
                // 至少一次
                .setDeliverGuarantee(DeliveryGuarantee.AT_LEAST_ONCE)
                // 如果上述设置了精准一致，那么必须要设置事务的前缀
                // .setTransactionalIdPrefix("ds")
                .setKafkaProducerConfig(properties)
                .build();

        source.sinkTo(kafkaSink);

        env.execute();
    }
}

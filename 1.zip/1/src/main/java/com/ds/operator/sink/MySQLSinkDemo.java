package com.ds.operator.sink;

import org.apache.flink.connector.jdbc.JdbcConnectionOptions;
import org.apache.flink.connector.jdbc.JdbcExecutionOptions;
import org.apache.flink.connector.jdbc.JdbcSink;
import org.apache.flink.streaming.api.environment.StreamExecutionEnvironment;

public class MySQLSinkDemo {
    public static void main(String[] args) throws Exception{
        StreamExecutionEnvironment env = StreamExecutionEnvironment.getExecutionEnvironment();



        env.fromElements(
                new Book(101,"xiyouji","wuchengen",1892),
                new Book(102,"sanguo","luoguanzhong",1882)
        )
                .addSink(JdbcSink.sink(
                        // sql模板
                        "insert into books1(id,title,authors,year) values(?,?,?,?)",
                        // 填充模板
                        (statement,book) ->{
                            statement.setInt(1,book.getId());
                            statement.setString(2,book.getTitle());
                            statement.setString(3,book.getAuthors());
                            statement.setInt(4,book.getYear());
                        },
                        // JDBC中flin相关的设置
                        JdbcExecutionOptions.builder()
                                .withMaxRetries(3)
                                .build(),
                        // JDBC中连接相关的设置
                        new JdbcConnectionOptions.JdbcConnectionOptionsBuilder()
                                .withUrl("jdbc:mysql://ds-bigdata-001:3306/ds_test")
                                .withDriverName("com.mysql.jdbc.Driver")
                                .withUsername("ds_read")
                                .withPassword("ds#readA0906")
                                .build()
                        ));

        env.execute();
    }

    public static class Book{
        private int id;
        private String title;
        private String authors;
        private int year;

        public Book() {
        }

        public Book(int id, String title, String authors, int year) {
            this.id = id;
            this.title = title;
            this.authors = authors;
            this.year = year;
        }

        public int getId() {
            return id;
        }

        public void setId(int id) {
            this.id = id;
        }

        public String getTitle() {
            return title;
        }

        public void setTitle(String title) {
            this.title = title;
        }

        public String getAuthors() {
            return authors;
        }

        public void setAuthors(String authors) {
            this.authors = authors;
        }

        public int getYear() {
            return year;
        }

        public void setYear(int year) {
            this.year = year;
        }
    }
}

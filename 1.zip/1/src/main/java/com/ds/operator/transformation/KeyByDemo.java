package com.ds.operator.transformation;

import org.apache.flink.api.common.RuntimeExecutionMode;
import org.apache.flink.api.java.functions.KeySelector;
import org.apache.flink.api.java.tuple.Tuple2;
import org.apache.flink.api.java.tuple.Tuple3;
import org.apache.flink.streaming.api.environment.StreamExecutionEnvironment;

public class KeyByDemo {

    public static void main(String[] args) throws Exception {
        StreamExecutionEnvironment env = StreamExecutionEnvironment.getExecutionEnvironment();
        env.setParallelism(1);

        // keyed state：是和key绑定的
        // keyed zs:  max("zs",7,"w")  maxBy("zs",7,"m")
        // keyed ww: max("ww",5)
        //keyed  ls: max("ls",53)
        env.fromElements(Tuple3.of("zs",5,"w"),
                        Tuple3.of("zs",7,"m"),
                        Tuple3.of("ww",5, "w"),
                        Tuple3.of("ls",3, "w"))
           .keyBy(key -> key.f0)
                .maxBy(1)
                .print();
        env.execute();
    }
}

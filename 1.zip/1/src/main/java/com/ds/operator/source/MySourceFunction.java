package com.ds.operator.source;

import org.apache.flink.streaming.api.functions.source.ParallelSourceFunction;
import org.apache.flink.streaming.api.functions.source.SourceFunction;

import java.util.Random;

public class MySourceFunction implements ParallelSourceFunction<Integer> {
    private boolean running = true;
    @Override
    public void run(SourceContext<Integer> ctx) throws Exception {
        while (running){
            Random random = new Random();
            int i = random.nextInt();
            ctx.collect(i);
//            Thread.sleep(1000);
        }
    }

    @Override
    public void cancel() {
        running = false;
    }
}

package com.ds.operator.source;

import org.apache.flink.api.common.typeinfo.Types;
import org.apache.flink.streaming.api.environment.StreamExecutionEnvironment;
import org.apache.flink.streaming.api.functions.source.datagen.DataGeneratorSource;
import org.apache.flink.streaming.api.functions.source.datagen.RandomGenerator;
import org.apache.flink.streaming.api.functions.source.datagen.SequenceGenerator;

import java.util.ArrayList;
import java.util.Arrays;
import java.util.List;
import java.util.Random;

public class DataGenSource {
    public static void main(String[] args) throws Exception{
        StreamExecutionEnvironment env = StreamExecutionEnvironment.getExecutionEnvironment();
//        env.addSource(new DataGeneratorSource<>(RandomGenerator.stringGenerator(20)),
//                "random",
//                        Types.STRING
//        ).print();

//        env.addSource(new DataGeneratorSource<>(SequenceGenerator.longGenerator(1, 1000)),
//                "random",
//                Types.LONG
//        ).print();

        env.addSource(new DataGeneratorSource<>(new MyRandom()),
                "random",
                Types.POJO(Person.class)
        ).print();

        env.execute();
    }
}


class MyRandom extends RandomGenerator<Person>{
    private final List<String> names = Arrays.asList("zs","ls","ww","zl");

    @Override
    public Person next() {
        Random random = new Random();
        String name = names.get(random.nextInt(4));
        int age = random.nextInt(100);
        return new Person(name,age);
    }
}

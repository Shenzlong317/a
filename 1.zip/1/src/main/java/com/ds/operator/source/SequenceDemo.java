package com.ds.operator.source;

import org.apache.flink.streaming.api.environment.StreamExecutionEnvironment;

public class SequenceDemo {
    public static void main(String[] args) throws Exception {
        StreamExecutionEnvironment env = StreamExecutionEnvironment.getExecutionEnvironment();
        env.fromSequence(1,1000)
                .print().setParallelism(2);

        env.execute();
    }
}

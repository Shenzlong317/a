package com.ds.operator.source;

import org.apache.flink.api.common.eventtime.WatermarkStrategy;
import org.apache.flink.api.common.serialization.SimpleStringSchema;
import org.apache.flink.connector.file.sink.compactor.SimpleStringDecoder;
import org.apache.flink.connector.kafka.source.KafkaSource;
import org.apache.flink.connector.kafka.source.enumerator.initializer.OffsetsInitializer;
import org.apache.flink.streaming.api.environment.StreamExecutionEnvironment;

public class KafkaSourceDemo {
    public static void main(String[] args) throws Exception{
        StreamExecutionEnvironment env = StreamExecutionEnvironment.getExecutionEnvironment();

        KafkaSource kafkaSource = KafkaSource.<String>builder()
                   .setBootstrapServers("ds-bigdata-002:9092,ds-bigdata-003:9092,ds-bigdata-004:9092")
                   .setTopics("")
                   .setGroupId("ds-whj")
                   .setStartingOffsets(OffsetsInitializer.earliest())
                   .setValueOnlyDeserializer(new SimpleStringSchema())
                   .build();


        env.fromSource(kafkaSource, WatermarkStrategy.noWatermarks(),"kafka source")
                        .print();

        env.execute();
    }


}

package com.ds.operator.transformation;

import org.apache.flink.api.common.functions.RichMapFunction;
import org.apache.flink.api.common.functions.RuntimeContext;
import org.apache.flink.api.java.tuple.Tuple3;
import org.apache.flink.configuration.Configuration;
import org.apache.flink.streaming.api.environment.StreamExecutionEnvironment;

public class RichFunctionDemo {
    public static void main(String[] args) throws Exception{
        StreamExecutionEnvironment env = StreamExecutionEnvironment.getExecutionEnvironment();

        env.fromElements(Tuple3.of("zs",5,"w"),
                        Tuple3.of("zs",7,"m"),
                        Tuple3.of("ww",5, "w"),
                        Tuple3.of("ls",3, "w"))
                        .map(new RichMapFunction<Tuple3<String, Integer, String>, Tuple3<String, Integer, String>>() {

                            @Override
                            public void open(Configuration parameters) throws Exception {
                                super.open(parameters);
                                RuntimeContext runtimeContext = getRuntimeContext();
                                int indexOfThisSubtask = runtimeContext.getIndexOfThisSubtask();
                                String taskNameWithSubtasks = runtimeContext.getTaskNameWithSubtasks();
                                System.out.println("index is" + indexOfThisSubtask + ",subTask name is " + taskNameWithSubtasks);
                            }

                            @Override
                            public Tuple3<String, Integer, String> map(Tuple3<String, Integer, String> value) throws Exception {
                                return Tuple3.of(value.f0, value.f1 +1, value.f2);
                            }
                        })
                                .print();

        env.execute();
    }
}

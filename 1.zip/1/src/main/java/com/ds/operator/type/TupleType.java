package com.ds.operator.type;

import org.apache.flink.api.java.tuple.Tuple2;
import org.apache.flink.streaming.api.datastream.DataStreamSource;
import org.apache.flink.streaming.api.environment.StreamExecutionEnvironment;

public class TupleType {
    public static void main(String[] args) {
        StreamExecutionEnvironment env = StreamExecutionEnvironment.getExecutionEnvironment();
        DataStreamSource<Tuple2<Integer, String>> tuple2DataStreamSource = env.fromElements(
                new Tuple2<>(18, "zhangsan"),
                new Tuple2<>(19, "lisi")

        );
    }
}

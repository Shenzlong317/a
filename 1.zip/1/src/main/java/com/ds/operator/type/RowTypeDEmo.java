package com.ds.operator.type;

import org.apache.flink.api.common.typeinfo.Types;
import org.apache.flink.api.java.typeutils.RowTypeInfo;
import org.apache.flink.streaming.api.datastream.DataStreamSource;
import org.apache.flink.streaming.api.environment.StreamExecutionEnvironment;
import org.apache.flink.types.Row;

public class RowTypeDEmo {
    public static void main(String[] args) {
        RowTypeInfo rowTypeInfo = new RowTypeInfo(Types.INT, Types.STRING);


        StreamExecutionEnvironment executionEnvironment = StreamExecutionEnvironment.getExecutionEnvironment();
        Row row = new Row(rowTypeInfo.getArity());
        row.setField(0,1);
        row.setField(1,"zhangsan");
        DataStreamSource<Row> rowDataStreamSource = executionEnvironment.fromElements(row);
    }

}

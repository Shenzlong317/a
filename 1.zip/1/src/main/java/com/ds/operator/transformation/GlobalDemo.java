package com.ds.operator.transformation;

import com.ds.EmptyJob;
import org.apache.flink.streaming.api.datastream.DataStreamSource;
import org.apache.flink.streaming.api.environment.StreamExecutionEnvironment;

public class GlobalDemo {
    public static void main(String[] args) throws Exception{
        StreamExecutionEnvironment env = StreamExecutionEnvironment.getExecutionEnvironment();

        DataStreamSource<EventRecord> stream = env.fromElements(
                new EventRecord("Mary", "./home", 1000L),
                new EventRecord("Bob", "./cart", 2000L),
                new EventRecord("Alice", "./prod?id=100", 3000L),
                new EventRecord("Bob", "./prod?id=1", 3300L),
                new EventRecord("Bob", "./home", 3500L),
                new EventRecord("Alice", "./prod?id=200", 3200L),
                new EventRecord("Bob", "./prod?id=2", 3800L),
                new EventRecord("Bob", "./prod?id=3", 4200L)
        );

        stream.global().print();

        // 空跑任务
        env.addSource(new EmptyJob()).print();

        env.execute();
    }
}

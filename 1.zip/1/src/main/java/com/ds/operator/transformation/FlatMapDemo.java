package com.ds.operator.transformation;

import org.apache.flink.api.common.functions.FlatMapFunction;
import org.apache.flink.api.common.typeinfo.Types;
import org.apache.flink.api.java.tuple.Tuple2;
import org.apache.flink.streaming.api.environment.StreamExecutionEnvironment;
import org.apache.flink.util.Collector;

public class FlatMapDemo {
    public static void main(String[] args) throws Exception{
        StreamExecutionEnvironment env = StreamExecutionEnvironment.getExecutionEnvironment();
        // Array(Hello Spark) Array(Hello Flink)  => Array(Hello Spark Hello Flink)
//        env.fromElements("Hello Spark", "Hello Flink")
//                .flatMap((String value, Collector<Tuple2<String,Integer>>out) -> {
//                    String[] s = value.split(" ");
//                    for (String word :s){
//                        Tuple2<String, Integer> wc = Tuple2.of(word, 1);
//                        out.collect(wc);
//                    }
//                })
//                .returns(Types.TUPLE(Types.STRING, Types.INT))
//                .print();

        env.fromElements("Hello Spark", "Hello Flink")
                .flatMap(new FlatMapFunction<String, Tuple2<String, Integer>>() {
                    @Override
                    public void flatMap(String value, Collector<Tuple2<String, Integer>> out) throws Exception {
                        String[] s = value.split(" ");
                        for (String word :s){
                            Tuple2<String, Integer> wc = Tuple2.of(word, 1);
                            out.collect(wc);
                        }
                    }
                })
                        .print();


        env.execute();
    }
}

package com.ds.operator.sink;

import org.apache.flink.api.common.serialization.SimpleStringEncoder;
import org.apache.flink.api.common.typeinfo.Types;
import org.apache.flink.configuration.MemorySize;
import org.apache.flink.connector.file.sink.FileSink;
import org.apache.flink.core.fs.Path;
import org.apache.flink.streaming.api.datastream.DataStreamSource;
import org.apache.flink.streaming.api.datastream.SingleOutputStreamOperator;
import org.apache.flink.streaming.api.environment.StreamExecutionEnvironment;
import org.apache.flink.streaming.api.functions.sink.filesystem.OutputFileConfig;
import org.apache.flink.streaming.api.functions.sink.filesystem.bucketassigners.DateTimeBucketAssigner;
import org.apache.flink.streaming.api.functions.sink.filesystem.rollingpolicies.DefaultRollingPolicy;
import org.apache.flink.streaming.api.functions.source.datagen.DataGeneratorSource;
import org.apache.flink.streaming.api.functions.source.datagen.RandomGenerator;

import java.time.Duration;
import java.util.stream.Stream;

public class FileSinkDemo {
    public static void main(String[] args) throws Exception{
        StreamExecutionEnvironment env = StreamExecutionEnvironment.getExecutionEnvironment();
        env.enableCheckpointing(10000);

        SingleOutputStreamOperator<String> source = env.addSource(new DataGeneratorSource<String>(RandomGenerator.stringGenerator(10)))
                .returns(Types.STRING);

        FileSink<String> fileSink = FileSink.<String>forRowFormat(
                        new Path("c:/xyz2/"),
                        new SimpleStringEncoder<String>())
                .withOutputFileConfig(
                        OutputFileConfig.builder()
                                .withPartPrefix("ds")
                                .withPartSuffix(".log")
                                .build()

                )
                .withBucketAssigner(new DateTimeBucketAssigner<>())
                .withRollingPolicy(
                        DefaultRollingPolicy.builder()
                                .withRolloverInterval(Duration.ofSeconds(10))
                                .withMaxPartSize(MemorySize.ofMebiBytes(1))
                                .withInactivityInterval(Duration.ofMillis(1))
                                .build()
                )
                .build();

        source.sinkTo(fileSink);

        env.execute();


    }
}

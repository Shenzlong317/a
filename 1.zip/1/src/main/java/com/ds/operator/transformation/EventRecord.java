package com.ds.operator.transformation;

// POJO
public class EventRecord{
    // 人名
    private String name;
    // 在浏览器上访问的url
    private String url;
    // 当时访问的时间
    private long ts;

    public EventRecord() {
    }

    public EventRecord(String name, String url, long ts) {
        this.name = name;
        this.url = url;
        this.ts = ts;
    }

    public String getName() {
        return name;
    }

    public void setName(String name) {
        this.name = name;
    }

    public String getUrl() {
        return url;
    }

    public void setUrl(String url) {
        this.url = url;
    }

    public long getTs() {
        return ts;
    }

    public void setTs(long ts) {
        this.ts = ts;
    }

    @Override
    public String toString() {
        return "EventRecord{" +
                "name='" + name + '\'' +
                ", url='" + url + '\'' +
                ", ts=" + ts +
                '}';
    }
}
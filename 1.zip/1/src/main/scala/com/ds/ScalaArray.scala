package com.ds

import org.apache.flink.streaming.api.scala.{StreamExecutionEnvironment, createTypeInformation}

object ScalaArray {
  def main(args: Array[String]): Unit = {
    val environment = StreamExecutionEnvironment.getExecutionEnvironment
    val value = environment.fromElements(1, 2, 3, 4)
    environment.fromCollection(Array(1,2,3,4))
    value.print()
    environment.execute()
  }
}

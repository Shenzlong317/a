package com.ds

import org.apache.flink.streaming.api.scala.{StreamExecutionEnvironment, createTypeInformation}

object CaseClasssType {
  def main(args: Array[String]): Unit = {
    val environment = StreamExecutionEnvironment.getExecutionEnvironment
    environment.fromElements(
      wc("hell0",1),
      wc("world",2)
    )
  }
}

case class wc(word:String, count:Int)
